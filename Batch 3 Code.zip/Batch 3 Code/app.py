from flask import Flask, render_template, request
import pickle
import re

app = Flask(__name__, template_folder='template')

@app.route('/')
def index():
    return render_template("hatespeechdetection.html")

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        
        text = request.form['input']
        print(f"Original Input: {text}")  # Debugging statement
        
        # Load the model
        try:
            with open('model.pkl', 'rb') as file:
                model = pickle.load(file)
            print("Model loaded successfully")  # Debugging statement
        except Exception as e:
            print(f"Error loading model: {e}")  # Debugging statement
            return render_template("hatespeechdetection.html", output="Error loading model")

        # Preprocess the text
        text = text.lower()
        text = re.sub(r"(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\S+)|^rt|http.+?", "", text)
        print(f"Processed Text: {text}")  # Debugging statement
        
        # Predict
        try:
            prediction = model.predict([text])
            print(f"Prediction: {prediction}")  # Debugging statement
            prediction = prediction[0]  # Extract the scalar value from the array
        except Exception as e:
            print(f"Error making prediction: {e}")  # Debugging statement
            return render_template("hatespeechdetection.html", output="Error making prediction")

        # Interpret the prediction
        if prediction == 0:
            output = "Not Hate Speech"
        else:
            output = "Hate Speech"
        
        return render_template("hatespeechdetection.html", output=output)

if __name__ == "__main__":
    app.run(debug=True)
